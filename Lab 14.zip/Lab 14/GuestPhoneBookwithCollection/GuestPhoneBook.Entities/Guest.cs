﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBook.Entities
{
    public enum Relation 
    {
        FATHER=1,
        MOTHER=2,
        BROTHER=3,
        SISTER=4,
        COUSIN=5,
        UNCLE=6,
        AUNT=7,
        SON=8,
        DAUGHTER=9,
        FRIEND=10,
    }
    public class Guest
    {
        private int guestID;

        public int GuestID
        {
            get { return guestID; }
            set { guestID = value; }
        }
        private string guestName;

        public string GuestName
        {
            get { return guestName; }
            set { guestName = value; }
        }
        private string guestContactNumber;

        public string GuestContactNumber
        {
            get { return guestContactNumber; }
            set { guestContactNumber = value; }
        }

        private Relation guestRelationship;

        public Relation GuestRelationship
        {
            get { return guestRelationship; }
            set { guestRelationship = value; }
        }

       

        public Guest()
        {
            guestID = 0;
            guestName = string.Empty;
            guestContactNumber = string.Empty;
        }
    }
}
