﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    //userdefined exception class
    class InvalidCreditLimit : Exception
    {
        //default constructor
        public InvalidCreditLimit()
        { }

        //parameterised constructor.
        public InvalidCreditLimit(string s): base(s)
        { }
    }
}
