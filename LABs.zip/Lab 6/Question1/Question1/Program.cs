﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer customer;
            try
            {
                //handle exception if occured
                customer = new Customer(1,"Vidya","Pune","Aurangabad","9876543214",70000);
                customer.printCustDetails();
            }
            catch (InvalidCreditLimit e)
            {
                //print error 
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
