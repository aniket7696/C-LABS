﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    //Task 1.
    class Customer
    {
        private int CustomerId;
        private string CustomerName, Address, City, Phone;
        private double CreditLimit;

        //Task 2.
        public int CustId
        {
            get
            {
                return CustomerId;
            }
            set
            {
                CustomerId = value;
            }
        }

        public string CustName
        {
            get
            {
                return CustomerName;
            }
            set
            {
                CustomerName = value;
            }
        }

        public string CusAddress
        {
            get
            {
                return Address;
            }
            set
            {
                Address = value;
            }
        }

        public string CusCity
        {
            get
            {
                return City;
            }
            set
            {
                City = value;
            }
        }

        public string CusPhone
        { 
            get
            {
                return Phone;
            }
            set
            {
                Phone = value;
            }
        }

        public double CusCreditLimit
        {
            get
            {
                return CreditLimit;
            }
            set
            {
                CreditLimit = value;
            }
        }

        //default constructor
        public Customer()
        {
            CustomerId = 0;
            CustomerName = " ";
            Address = " ";
            City = " ";
            Phone = " ";
            CreditLimit = 0.00;
        }

        //parameterized constructor.
        public Customer(int CustomerId, string CustomerName, string Address, string City, string Phone,double CreditLimit)
        {
            this.CustomerId = CustomerId;
            this.CustomerName = CustomerName;
            this.Address = Address;
            this.City = City;
            this.Phone = Phone;
            if (CreditLimit <= 50000)
            {
                this.CreditLimit = CreditLimit;
            }
            else
            {
                //throw object of user defined exception class InvalidCreditLimit.
                throw new InvalidCreditLimit("Invalid credit limit");
            }
            
        }
        public void printCustDetails()
        {
            Console.WriteLine("CustomerId: " + CustomerId + "\nCustomerName: " + CustomerName + "\nAddress: " + Address +
                "\nCity: " + City + "\nPhone: " + Phone + "\nCreditLimit: " + CreditLimit);
        }

        
    }
}
