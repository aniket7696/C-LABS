﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class ProductTest
    {
        int id;
        string name;
        double price;
        //create reference of ProductMock
     
        //get product details
        private ProductMock getProductDetails()
        {
            //create reference of ProductMock
            ProductMock product;
            try
            {
                //take input of product details from user.
                Console.Write("Enter Product ID: ");
                id = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Product Name: ");
                name = Console.ReadLine();

                Console.Write("Enter Product Price: ");
                price = Convert.ToInt32(Console.ReadLine());

                //assign values to ProductMock object.
                 product = new ProductMock(id, name, price);

                //return object of ProductMock.
                return product;

            }
            catch(DataEntryException e)
            {
                //catch respected exception and print it.
                Console.WriteLine(e.Message);
                return (product=null);
            }
        }

        //print product details
        private void DisplayDetails(ProductMock product)
        {
            /*If product object has not been null then print details of product object*/
            if (product != null)
            {
                Console.Write("Product Id: " + product._productID + "\nProduct Name: " + product._productName
                    + "\nPrice: " + product._price);
            }
            else
            {
               // Console.Write("");
            }
        }

        static void Main(string[] args)
        {
            //create object of ProductTest
            ProductTest productTest = new ProductTest();
            //create object of ProductMock
            ProductMock product = productTest.getProductDetails();

            productTest.DisplayDetails(product);
            Console.ReadLine();
        }
    }
}
