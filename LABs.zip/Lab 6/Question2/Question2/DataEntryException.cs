﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    class DataEntryException : ApplicationException
    {
        //default constructor
        public DataEntryException()
        { }

        //parameterized constructor
        public DataEntryException(string s) : base(s)
        {
        }

    }
}
