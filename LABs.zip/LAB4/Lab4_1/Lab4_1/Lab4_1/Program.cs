﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string name, address, city, department;
            int id;

            //creating objects of derived classes
            Lab4_1.ContractEmployee objContract = new Lab4_1.ContractEmployee();
            Lab4_1.PermanentEmp objPer = new Lab4_1.PermanentEmp();

            Console.WriteLine("enter details of employee");
            Console.WriteLine("enter employee Id:");
            id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter employee name:");
            name = Console.ReadLine();

            Console.WriteLine("enter employee address:");
            address = Console.ReadLine();

            Console.WriteLine("enter employee city:");
            city = Console.ReadLine();

            Console.WriteLine("enter employee department:");
            department = Console.ReadLine();

            Console.WriteLine("enter Contract employee salary:");
            objContract.ContractSal = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter Permanent employee salary:");
            objPer.PermSal = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter employee Perks:");
            objContract.Perks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter employee No of leaves:");
            objPer.NoOfLeaves = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter employee Fund:");
            objPer.ProvidendFund = Convert.ToInt32(Console.ReadLine());

            int result;
            int choice = Convert.ToInt32(Console.ReadLine());
            //enter choice
            switch (choice)
            {
                case 1:
                    result = objContract.GetSalary();
                    Console.WriteLine("New Salary:" + result);
                    break;
                case 2:
                    result = objPer.GetSalary();
                    Console.WriteLine("New Salary:" + result);
                    break;
                default:
                    break;
            }
            Console.ReadLine();
        }
    }
}
