﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    public class PermanentEmp : Employee
    {

        public int noOfleaves, providendfund, PermSal;
        int newSalary;
        public int NoOfLeaves
        {
            get
            {
                return noOfleaves;
            }
            set
            {
                noOfleaves = value;
            }
        }
        public int ProvidendFund
        {
            get
            {
                return providendfund;
            }
            set
            {
                providendfund = value;
            }
        }

        //override abstract class
        public override int GetSalary()
        {
            newSalary = PermSal - providendfund;
            return newSalary;
        }
    }
}
