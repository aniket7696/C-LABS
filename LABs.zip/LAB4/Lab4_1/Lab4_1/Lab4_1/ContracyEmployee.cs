﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    public sealed class ContractEmployee : Employee
    {

        public int _perks, newSalary, ContractSal;
        public int Perks
        {
            get
            {
                return _perks;
            }
            set
            {
                _perks = value;
            }
        }


        //override abstract class
        public override int GetSalary()
        {
            newSalary = ContractSal + _perks;
            return newSalary;
        }






    }
}
