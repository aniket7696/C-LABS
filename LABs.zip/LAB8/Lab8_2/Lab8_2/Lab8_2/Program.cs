﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_2

{
    class Program
    {
        static void Main(string[] args)
        {
            GetHashtable();
            Console.ReadLine();
        }

        static Hashtable GetHashtable()
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);

            //ContainsKey()
            if (hashtable.ContainsKey("Perimeter"))
                Console.WriteLine("hashtable contains the key");
            else
                Console.WriteLine("hashtable doesn't contain the key");

            if (hashtable.Contains("Perimeter"))
                Console.WriteLine("hashtable contains the key");
            else
                Console.WriteLine("hashtable doesn't contain the key");

            object objValue = hashtable["Area"];
            Console.WriteLine(objValue);

            //task3: remove mortgage
            hashtable.Remove("Mortgage");


            return hashtable;
        }



    }
}
