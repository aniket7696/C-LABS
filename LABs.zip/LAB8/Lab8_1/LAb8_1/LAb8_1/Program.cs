﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_1
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                Hashtable objHT = new Hashtable();
                char press;
                do
                {
                    Console.WriteLine(" Select Option \n 1)ADD \n 2)Search  \n 3) Display All  \n 4)Display Count \n 5)Remove Record");
                    int choice = int.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:

                            Console.WriteLine("Enter number of districts");
                            int n = int.Parse(Console.ReadLine());

                            for (int index = 0; index < n; index++)
                            {
                                District objDist = new District();
                                Console.WriteLine(" District details");
                                Console.Write("enter RTO info:");
                                objDist.RTO = Console.ReadLine();
                                Console.Write("enter District:");
                                objDist.District1 = Console.ReadLine();
                                objHT.Add(objDist.RTO, objDist.District1);
                            }
                            break;

                        //search
                        case 2:
                            string searchRTO;
                            Console.Write("enter RTO info to be search:");
                            searchRTO = Console.ReadLine();
                            foreach (var objValue in objHT.Keys)
                            {
                                if (objValue.ToString() == searchRTO)
                                {
                                    Console.WriteLine("RTO :" + objValue.ToString());
                                    Console.WriteLine("District : " + objHT[objValue]);

                                }

                                else
                                {
                                    Console.WriteLine("couldnot found");
                                }
                            }

                            break;

                        //Display all contacts
                        case 3:
                            Console.WriteLine("Display all :");
                            foreach (var objValue1 in objHT.Keys)

                            {
                                Console.WriteLine("RTO: " + objValue1.ToString() + " District: " + objHT[objValue1]);
                            }
                            break;

                        //Display count
                        case 4:
                            Console.WriteLine("Display count:");
                            Console.WriteLine("Count :" + objHT.Count);
                            break;


                        //Delete Record
                        case 5:
                            string RTO;
                            Console.Write("enter RTO no. to delete:");
                            RTO = Console.ReadLine();

                            if (objHT.ContainsKey(RTO))
                            {
                                //object objValue = objHT[RTO];
                                objHT.Remove(RTO);
                                Console.WriteLine("record deleted successfully");
                            }
                            else
                                Console.WriteLine("Enter valid key.");

                            break;

                    }
                    Console.WriteLine("Do u want to continue");
                    press = Convert.ToChar(Console.ReadLine());
                } while (press == 'y' || press == 'Y');

            }
            Console.ReadLine();
        }
    }
}