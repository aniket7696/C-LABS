﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_1
{
    class District
    {
        string rto, districts;

        public string District1
        {
            get
            {
                return districts;
            }
            set
            {
                districts = value;
            }
        }

        public string RTO
        {
            get
            {
                return rto;
            }
            set
            {
                rto = value;
            }
        }


    }
}
