﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contacts;

namespace Lab7_1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Contact> Contacts = new List<Contact>(8);
            char select;

            do
            {
                Console.WriteLine(" Select Option 1)ADD \n 2)Diplay ALL \n 3) Display Selected \n 4)EDIT \n ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:

                        Console.WriteLine("Enter number of contacts");
                        int n = int.Parse(Console.ReadLine());

                        for (int index = 0; index < n; index++)
                        {
                            Contact objContact = new Contact();
                            Console.WriteLine(" contact details");
                            objContact.ContactNo = int.Parse(Console.ReadLine());
                            objContact.ContactName = Console.ReadLine();
                            objContact.CellNo = Console.ReadLine();
                            Contacts.Add(objContact);

                        }
                        break;
                    case 2:

                        foreach (Contact c in Contacts)
                        {
                            Console.WriteLine("ContactNo={0}, ContactName={1}, CellNo={2}", c.ContactNo, c.ContactName, c.CellNo);
                        }
                        break;
                    case 3:

                        Console.WriteLine(" contact name you want to display");
                        string searchName = Console.ReadLine();

                        for (int index = 0; index < Contacts.Count; index++)
                        {
                            if (Contacts[index].ContactName == searchName)
                            {
                                Console.WriteLine("ContactNo={0}, ContactName={1}, CellNo={2}", Contacts[index].ContactNo, Contacts[index].ContactName, Contacts[index].CellNo);
                            }
                            else
                            {
                                Console.WriteLine(" Name not found");

                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine(" contact name you want to edit details of");
                        string editName = Console.ReadLine();
                        for (int index = 0; index < Contacts.Count; index++)
                        {
                            if (Contacts[index].ContactName == editName)
                            {
                                Console.WriteLine(" contact details");
                                Contacts[index].ContactNo = int.Parse(Console.ReadLine());
                                Contacts[index].ContactName = Console.ReadLine();
                                Contacts[index].CellNo = Console.ReadLine();
                            }
                            else
                            {
                                Console.WriteLine(" Name not found");
                            }




                        }
                        break;

                }
                Console.WriteLine("u want to continue");
                select = char.Parse(Console.ReadLine());

            } while (select != 'n');
        }
    }
}
