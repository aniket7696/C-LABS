﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Employee
{
    public class Employees
    {
        public int EmployeeNo { get; set; }
        public string EmployeeName { get; set; }
        public int salary { get; set; }
        public int pf { get; set; }

        public Employees()
        {
            EmployeeNo = 0;
            EmployeeName = "";
            salary = 0;
            pf = 0;
        }

        public Employees(int num,string name,int sal,int pf)
        {
            EmployeeNo = num;
            EmployeeName = name;
            salary = sal;
            this.pf = pf;
        }
    }
}
