﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_2
{
    public class Product
    {
        public int ProductNo { get; set; }
        public string ProductName { get; set; }
        public int Rate { get; set; }
        public int Stock { get; set; }
    }
}
