﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int EmpId, FoundationMarks, WebBasicMarks, TotalMarks, ObtainedMarks;
            string Name;
            string CompanyName;
            float Percentage;
           
            Console.Write("Enter Data");
            Console.WriteLine("Enter Employee Id");
            EmpId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            Name = (Console.ReadLine());
            Console.WriteLine("Enter Employee WebBasicMarks");
            WebBasicMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee ObtainedMarks");
            ObtainedMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Employee FoundationMarks");
            FoundationMarks = int.Parse(Console.ReadLine());
            Participant obj = new Participant(EmpId, WebBasicMarks, FoundationMarks,ObtainedMarks, Name);

            obj.calculateMarks();
            obj.calculatePercentage();
            obj.displayPercentage();





        }
    }
}
