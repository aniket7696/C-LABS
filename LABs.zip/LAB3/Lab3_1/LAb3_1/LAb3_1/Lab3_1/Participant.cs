﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_1
{
    class Participant
    {
       private int EmpId, FoundationMarks, WebBasicMarks, DotNetMarks, TotalMarks=300,ObtainedMarks;
       private  static string Name, CompanyName;
       private float Percentage;
       
        public Participant()
        {
            EmpId = 0;
            FoundationMarks = 0;
            WebBasicMarks = 0;
            DotNetMarks = 0;
           
            Name = "";
            CompanyName = "";
           


        }

        public Participant(int id,int fMarks,int wMarks,int dMarks,string _name)
        {
            EmpId = id;
            FoundationMarks = fMarks;
            WebBasicMarks = wMarks;
            DotNetMarks = dMarks;
            Name = _name;
            
            
        }

         static Participant()
        {
            CompanyName = "Corporate Unniversity";
        }


        public int calculateMarks()
        {
            TotalMarks = DotNetMarks + WebBasicMarks+FoundationMarks;
            return TotalMarks;
        }

        public float calculatePercentage()
        {
            Percentage = TotalMarks/3;
            return Percentage;
        }

        public void displayPercentage()
        {
            Console.WriteLine("Percentage is " + Percentage);
        }
    }
}
