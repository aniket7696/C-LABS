﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_3
{
    class CarsCatalog
    {
        public string model, makes;
        public int year,srNo;
        public double salesPrice;

        static int i=1;
        public CarsCatalog()
        {
            srNo = i++;
            makes = "";
            model = "";
            year = 0;
            salesPrice = 0;
        
        }
        public CarsCatalog(string model,string makes,int year,double salesPrice)
        {
            srNo = i++;
            this.model = model;
            this.makes = makes;
            this.year = year;
            this.salesPrice = salesPrice;
        }

        public void addCar()
        {
            Console.WriteLine("ENter Car makes");
            makes = Console.ReadLine();
            Console.WriteLine("ENter Car model");
            model = Console.ReadLine();
            Console.WriteLine("ENter Car year");
            year = int.Parse(Console.ReadLine());
            Console.WriteLine("ENter Car sales price");
            salesPrice = double.Parse(Console.ReadLine());
        }

        public bool search(int year)
        {
            if (this.year == year)
            {
                Console.Clear();
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Print()
        {
            Console.WriteLine("Sr No: \t" + srNo + "car makes \t" + makes + "year \t" + year + "model \t" + model + "sales price \t" + salesPrice);
        }

        public void modify(int srno)
        {
            if (this.srNo == srno)
            {
                addCar();
            }
            else
            {
                Console.WriteLine("Car Not Found");
            }
        }


    }
}
