﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmeticOperations
{
    class Operation
    {

        public int Addition(int num1, int num2)
        {
            return (num1 + num2);

        }

        public int Subtraction(int num1, int num2)
        {
            return (num1 - num2);
        }


        public int Multiplication(int num1, int num2)
        {
            return (num1 * num2);

        }

        public int Division(int num1, int num2)
        {
            return (num1 / num2);

        }



        public int Modulus(int num1, int num2)
        {
            return (num1 % num2);
        }

        public double Addition(double num1, double num2)
        {
            return (num1 + num2);

        }

        public double Subtraction(double num1, double num2)
        {
            return (num1 - num2);
        }


        public double Multiplication(double num1, double num2)
        {
            return (num1 * num2);

        }

        public double Division(double num1, double num2)
        {
            return (num1 / num2);

        }



        public double Modulus(double num1, double num2)
        {
            return (num1 % num2);


        }
    }
}