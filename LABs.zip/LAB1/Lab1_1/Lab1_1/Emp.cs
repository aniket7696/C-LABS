﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1
{
    class Emp
    {
        public string empName, address, city, department;
        public int empId, salary;

        // Declare a Name property of type string:
        public string Name
        {
            get
            {
                return empName;
            }
            set
            {
                empName = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        public string Address1
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }

        public string Department
        {
            get
            {
                return department;
            }
            set
            {
                department = value;
            }
        }

        public int EmpId
        {
            get
            {
                return empId;
            }
            set
            {
                empId = value;
            }
        }
    }
}