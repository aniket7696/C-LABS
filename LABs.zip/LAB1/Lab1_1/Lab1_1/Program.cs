﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1
{
    //Task-1 and 4
    class Program
    {
        static void Main(string[] args)
        {
            Emp[] obj = new Emp[2];

            for (int index = 0; index < obj.Length; index++)
            {
                obj[index] = new Emp();
            }

            for (int index = 0; index < obj.Length; index++)
            {
                Console.WriteLine("enter details of employee");

                Console.WriteLine("enter employee Id:");
                obj[index].EmpId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter employee name:");
                obj[index].empName = Console.ReadLine();

                Console.WriteLine("enter employee address:");
                obj[index].address = Console.ReadLine();

                Console.WriteLine("enter employee city:");
                obj[index].city = Console.ReadLine();

                Console.WriteLine("enter employee department:");
                obj[index].department = Console.ReadLine();

                Console.WriteLine("enter employee salary:");
                obj[index].salary = Convert.ToInt32(Console.ReadLine());
            }

            for (int index = 0; index < obj.Length; index++)
            {
                Console.WriteLine("Employee Name:" + obj[index].empName);
                Console.WriteLine("Employee salary:" + obj[index].salary);
            }
            Console.ReadLine();
        }
    }
}
