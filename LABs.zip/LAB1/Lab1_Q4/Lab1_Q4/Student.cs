﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Q4
{
    class Student
    {
        int rollNumber;
        string studentName, address;
        byte age;
        char gender;
        DateTime dob;
        float percentage;

        public void studentDetails(
        int rollNumber,
        string studentName, string address,
        byte age,
        char gender,
        DateTime dob,
        float percentage)
        {
            this.rollNumber = rollNumber;
            this.studentName = studentName;
            this.address = address;
            this.age = age;
            this.gender = gender;
            this.dob = dob;
            this.percentage = percentage;

        }

        public void display()
        {
            Console.WriteLine(rollNumber + studentName + address + age + gender + dob + percentage);
        }
    }
}
