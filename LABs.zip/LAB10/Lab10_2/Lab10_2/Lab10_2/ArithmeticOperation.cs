﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_2
{
    public delegate void ArithmeticHandler(int firstNumber, int secondNumber);
    class ArithmeticOperation
    {
        public void Addition(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Addtion of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber + secondNumber);

        }
        public static void PerformArithmeticOperation(int num1, int num2, ArithmeticHandler arOperation)
        {
            arOperation.Invoke(num1, num2);
        }
    }
}
