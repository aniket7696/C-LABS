﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_1
{
    public delegate void ArithmeticHandler(int firstNumber, int secondNumber);
    class ArithmeticOperation
    {
        //Creating a Delegate
       

        public void Addition(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Addtion of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber + secondNumber);

        }
        public void Subtraction(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Subtraction of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber - secondNumber);

        }
        public void Multiply(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Multiplion of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber * secondNumber);

        }
        public void Divide(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Division of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber / secondNumber);

        }
        public void Max(int firstNumber, int secondNumber)
        {
            if(firstNumber>secondNumber)
            Console.WriteLine("MAximum of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber );
            else
                Console.WriteLine("MAximum of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber);


        }

       
    }
}
