﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Contacts;


namespace Lab13_1
{
    class Program
    {
        static void Main(string[] args)
        {
            SerializeData();

        }
        private static void SerializeData()
        {
            try
            {
                Contact objContact = new Contact();
                objContact.ContactNo = 1;
                objContact.ContactName = "a";
                objContact.CellNo = "9876543210";
                FileStream fileStream = new FileStream("C:\\Users\\mohdsalk\\Documents\\ser.dat", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, objContact);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
