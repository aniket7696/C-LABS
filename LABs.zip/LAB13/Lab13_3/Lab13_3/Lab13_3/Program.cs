﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Collections;
using System.Runtime.Serialization.Formatters.Soap;
using Contacts;

namespace Lab13_3
{
    class Program
    {
        static void Main(string[] args)
        {
            SerializeData();
            DeserializeData();

        }
        private static void SerializeData()
        {
            ArrayList ContactList = new ArrayList();
            try
            {
                Console.WriteLine("Enter number of contacts");
                int n = int.Parse(Console.ReadLine());

                for (int index = 0; index < n; index++)
                {
                    Contact objContact = new Contact();
                    Console.WriteLine(" contact details");
                    objContact.ContactNo = int.Parse(Console.ReadLine());
                    objContact.ContactName = Console.ReadLine();
                    objContact.CellNo = Console.ReadLine();
                    ContactList.Add(objContact);
                }

                FileStream fileStream = new FileStream("C:\\Users\\mohdsalk\\Documents\\her.dat", FileMode.Create);
                SoapFormatter formatter = new SoapFormatter();
                formatter.Serialize(fileStream, ContactList);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeserializeData()
        {
            try
            {
                FileStream fileStream = new FileStream("C:\\Users\\mohdsalk\\Documents\\her.dat", FileMode.Open);
                SoapFormatter formatter = new SoapFormatter();
                ArrayList obj = (ArrayList)formatter.Deserialize(fileStream);
                fileStream.Close();
                foreach (Contact c in obj)
                {
                    Console.WriteLine("Cell No:" + c.CellNo + "Name:" + c.ContactName);
                }



            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
