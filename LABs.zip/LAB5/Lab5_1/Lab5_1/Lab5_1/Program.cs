﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_1
{
    class Program
    {
        static void Main(string[] args)
        {


                ICICI obj1 = new ICICI();
                Console.WriteLine(BankAccountType.current);
                Console.WriteLine("balance:" + obj1.GetBalance());
                //Print the Balance of current account objects.
                Console.WriteLine("current balance of ICICI:" + obj1.Deposit(500000));
                Console.WriteLine();

                ICICI obj2 = new ICICI();
                Console.WriteLine(BankAccountType.saving);
                Console.WriteLine("balance:" + obj2.GetBalance());
                //Print the Balance of savings account objects.
                Console.WriteLine("savings balance of ICICI:" + obj2.Deposit(200000));





                //Now call the Transfer function to transfer the money from Savings account to Current Account.The amount to be transferred is Rs. 5000.
                obj2.Transfer(obj1, 5000);

                //Now print the Balance after the Transfer from both the accounts.
                Console.WriteLine("balance after transaction:" + obj1.Deposit(0));


                Console.WriteLine();
                //For HSBC Bank
                HSBC obj3 = new HSBC();
                Console.WriteLine(BankAccountType.current);
                Console.WriteLine("balance:" + obj1.GetBalance());
                //Print the Balance of current account objects.
                Console.WriteLine("current balance of of HSBC:" + obj3.Deposit(500000));
                Console.WriteLine();

                HSBC obj4 = new HSBC();
                Console.WriteLine(BankAccountType.saving);
                Console.WriteLine("balance:" + obj4.GetBalance());
                //Print the Balance of savings account objects.
                Console.WriteLine("current balance of of HSBC:" + obj4.Deposit(200000));

                obj4.Transfer(obj3, 30000);
                Console.WriteLine("balance after transaction:" + obj3.Deposit(5000));




                Console.ReadLine();
            
        }
    }
}
