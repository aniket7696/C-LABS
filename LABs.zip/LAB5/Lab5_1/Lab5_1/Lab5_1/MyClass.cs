﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_1
{
    public enum BankAccountType
    {
        current = 1,
        saving = 2
    }

    class MyClass
    {
        BankAccountType toAccount;

        public BankAccountType AccountType
        {
            get
            {
                return toAccount;
            }
            set
            {
                toAccount = value;
            }
        }
    }

    public interface IBankAccount
    {

        double GetBalance();
        double Deposit(double amount);
        bool Withdraw(double amount);
        bool Transfer(IBankAccount toAccount, double amount);

    }

}

