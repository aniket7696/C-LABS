﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_2
{
    public abstract class BankAccount : IBankAccount
    {
        string name;
        int number;
        public double balance;

        public string AccountOwnerName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public int AccountNumber
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
        protected double Balance
        {
            get
            {
                return balance;
            }
            set

            {
                balance = Convert.ToInt32(value);
            }
        }

        public double GetBalance()
        {
            //code here   
            Console.WriteLine("enter balance :");
            Balance = Convert.ToDouble(Console.ReadLine());
            return Balance;
        }
        public double Deposit(double amount)
        {
            Balance = Balance + Convert.ToInt32(amount);
            return Balance;
        }

        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);
        public abstract double CalculateInterest(int yr);

    }
}
