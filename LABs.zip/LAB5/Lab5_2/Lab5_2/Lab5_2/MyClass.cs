﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_2
{
    public enum BankAccountType
    {
        current = 1,
        saving = 2
    }

    public class MyClass
    {
        BankAccountType toAccount;

        public BankAccountType AccountType
        {
            get
            {
                return toAccount;
            }
            set
            {
                toAccount = value;
            }
        }
    }

    public interface IBankAccount
    {

        double GetBalance();
        double Deposit(double amount);
        bool Withdraw(double amount);
        bool Transfer(IBankAccount toAccount, double amount);
        double CalculateInterest(int yr);

    }
}
