﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_2
{
   
    public class ICICI : BankAccount
    {
        double interest;
        int rate = 7;

        public override bool Withdraw(double amount) // Override this method
        {

            if ((Balance - amount) > 0)
            {
                Balance -= amount;
            }
            return true;
        }

        public override bool Transfer(IBankAccount toAccount, double amount) //Override this method
        {


            if (Balance > 1000)
            {
                toAccount.Deposit(amount);

            }
            return true;
        }
        public override double CalculateInterest(int yr)
        {
            interest = (Balance * yr * rate) / 100;
            return interest;
        }


    }
}
