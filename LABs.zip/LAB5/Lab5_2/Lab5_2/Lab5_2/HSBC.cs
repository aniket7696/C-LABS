﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_2
{
    
    public class HSBC : BankAccount
    {
        double interest;
        int rate = 7;

        public override bool Withdraw(double amount) // Override this method
        {

            if ((Balance - amount) > 1000)
            {
                Balance -= amount;
            }
            return true;
        }
        public override bool Transfer(IBankAccount toAccount, double amount) //Override this method
        {
            Withdraw(amount);
            // If Balance – Withdraw is >= 1000 then only transfer can take place.Write the code to achieve the same.
            if ((Balance - amount) > 5000)
            {
                toAccount.Deposit(amount);

            }
            return true;
        }

        public override double CalculateInterest(int yr)
        {
            interest = (Balance * yr * rate) / 100;
            return interest;
        }

    }
}
