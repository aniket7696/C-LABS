﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Product obj = new Product();
            int id, quantity;
                double price;
            string name;
            Console.WriteLine("Enter Product Details");
            Console.WriteLine("Enter Product Id");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Price");
            price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Product quantity");
            quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product name");
            name = Console.ReadLine();
            obj.acceptDetails(id, name, price, quantity);
            obj.productDisplay();
        }
    }
}
