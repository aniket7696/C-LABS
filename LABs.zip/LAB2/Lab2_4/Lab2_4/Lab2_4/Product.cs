﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    class Product
    { 
           private object productId;
        private object price, quantity;
           private double amountPayable;
        private object productName;

            public void acceptDetails(int id, string name, double price, int quantity)
            {
            //Doing Boxing
                productId = id;
                productName = name;
                this.price = price;
                this.quantity = quantity;

            }

        public void productDisplay()
        {
            //UnBoxing
            Console.WriteLine("Product Id: " + (int)productId);
            Console.WriteLine("Product Name: " + (string)productName);
            Console.WriteLine("Product quantity: " + (int)quantity);
            Console.WriteLine("Product Price: " + (double)price);
            Console.WriteLine("Product Total Amount: " + ((int)quantity * (double)price));


        }

           
        }
    }

    

