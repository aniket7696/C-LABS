﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_5
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] bookTitle = new string[] { "BOOK TITLE", "AUTHOR", "PUBLISHER", "PRICE" };
            string[,] book = new string[2, 4];
            Console.WriteLine("Enter book Details:");

            for (int r = 0; r < book.GetLength(0); r++)
            {
                for (int c = 0; c < book.GetLength(1); c++)
                {
                    if (r == 0)
                    {
                        book[0, 0] = bookTitle[0];
                        book[0, 1] = bookTitle[1];
                        book[0, 2] = bookTitle[2];
                        book[0, 3] = bookTitle[3];
                    }
                    else
                    {
                        book[r, c] = Console.ReadLine();
                    }

                }

            }

            for (int r = 0; r < book.GetLength(0); r++)
            {
                for (int c = 0; c < book.GetLength(1); c++)
                {
                    Console.Write(book[r, c] + " ");
                }
                Console.WriteLine();

            }
            Console.ReadLine();
        }
    }
    
}
