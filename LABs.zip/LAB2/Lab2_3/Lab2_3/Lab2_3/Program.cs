﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Enter number of City  ");
            int n = Convert.ToInt32(Console.ReadLine());
            string[] city = new string[n];
            for(int i = 0;i<n;i++)
            {
                Console.WriteLine("Enter City names ");
                city[i] = Console.ReadLine();

            }

            foreach(string cities in city)
            {
                Console.WriteLine(cities);
            }
        }
    }
}
