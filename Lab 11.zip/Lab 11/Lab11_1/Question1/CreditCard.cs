﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankAccount;

namespace Question1
{
    public delegate void MakePayment(double amount);

    public class CreditCard :BankAccount.BankAccount
    {
        public event MakePayment makePay;
        //
        private string creditCardNo, cardHolderName;
        private double balanceAmount, creditLimit;

        public string CreditCardNo
        {
            get {return creditCardNo; }
            set { creditCardNo = value; }
        }

        public string CardHolderName
        {
            get { return cardHolderName; }
            set { cardHolderName = value; }
        }

        public double BalanceAmount
        {
            get { return balanceAmount; }
            set { balanceAmount = value; }
        }

        public double CreditLimit
        {
            get { return creditLimit; }
            set { creditLimit = value; }
        }
        
        public override double GetBalance()
        {
            return balanceAmount;
        }

        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            throw new NotImplementedException();
        }

        public override bool Withdraw(double amount)
        {
            throw new NotImplementedException();
        }

        public void MakePayment(double amount)
        {
            double previousBlance = BalanceAmount; 
            BalanceAmount += amount;
            if(previousBlance < BalanceAmount)
            {
                makePay(previousBlance);
            }
        }
    }
}
